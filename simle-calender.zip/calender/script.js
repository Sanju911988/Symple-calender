const monthYear = document.getElementById("monthYear");
const daysContainer = document.getElementById("days");
const prev = document.getElementById("prev");
const next = document.getElementById("next");

let currentDate = new Date();

function renderCalendar(date) {
  const year = date.getFullYear();
  const month = date.getMonth();

  const firstDay = new Date(year, month, 1).getDay();
  const lastDate = new Date(year, month + 1, 0).getDate();

  const today = new Date();
  const isCurrentMonth = month === today.getMonth() && year === today.getFullYear();

  daysContainer.innerHTML = "";
  monthYear.textContent = `${date.toLocaleString("default", { month: "long" })} ${year}`;

  // Add empty divs for first day offset
  for (let i = 0; i < firstDay; i++) {
    daysContainer.innerHTML += `<div></div>`;
  }

  // Fill in days
  for (let i = 1; i <= lastDate; i++) {
    const dayDiv = document.createElement("div");
    dayDiv.textContent = i;

    if (isCurrentMonth && i === today.getDate()) {
      dayDiv.classList.add("today");
    }

    dayDiv.addEventListener("click", () => {
      const event = prompt(`Add an event for ${i} ${month + 1}, ${year}:`);
      if (event) {
        localStorage.setItem(`${year}-${month}-${i}`, event);
        alert("Saved!");
      }
    });

    daysContainer.appendChild(dayDiv);
  }
}

prev.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() - 1);
  renderCalendar(currentDate);
});

next.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() + 1);
  renderCalendar(currentDate);
});

renderCalendar(currentDate);
